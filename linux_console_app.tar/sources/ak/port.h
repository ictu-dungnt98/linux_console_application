#ifndef __PORT_H__
#define __PORT_H__

#define __AK_PACKETED	__attribute__((__packed__))
#define __AK_WEAK	__attribute__((__weak__))

#endif //__PORT_H__
