#include <sys/types.h>
#include <sys/stat.h>

#include "ak.h"

#include "app.h"
#include "app_dbg.h"

void task_init() {
}
