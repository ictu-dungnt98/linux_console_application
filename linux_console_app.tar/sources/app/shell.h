#ifndef __SHELL_H__
#define __SHELL_H__

#include "cmd_line.h"

extern cmd_line_t lgn_cmd_table[];

#endif //__SHELL_H__
