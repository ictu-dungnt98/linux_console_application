#ifndef __TASK_CONSOLE_H__
#define __TASK_CONSOLE_H__

#include "message.h"

extern q_msg_t gw_task_console_mailbox;
extern void* gw_task_console_entry(void*);

#endif //__TASK_CONSOLE_H__
