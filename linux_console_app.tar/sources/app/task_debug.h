#ifndef __TASK_DEBUG_H__
#define __TASK_DEBUG_H__

#include "message.h"

extern q_msg_t gw_task_debug_mailbox;
extern void* gw_task_debug_entry(void*);

#endif //__TASK_DEBUG_H__
